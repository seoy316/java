package com.example.Array1;

import java.util.Scanner;

public class Array9063_ex {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        for (int i=0; i<5; i++)
            System.out.printf("%d ", sc.nextInt());
    }
}
