package com.jeongol.Loop1;

public class Loop9039_ex {
    public class Main {
        public static void main(String[] args) {
            for (char i = 'A'; i <= 'Z'; i++)
                System.out.printf("%c", i);
        }
    }
}
